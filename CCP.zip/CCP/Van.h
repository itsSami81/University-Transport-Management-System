#ifndef VAN_H
#define VAN_H

#include "Vehicle.h"

class Van : public Vehicle
{
private:
    bool acAvailable;

public:
    Van();
    Van(int, string, int, bool);
    Van(const Van&);
    Van& operator=(const Van&);

    void setAC(bool);
    bool getAC() const;

    void displayVehicle() override;
    ~Van();
};

#endif
