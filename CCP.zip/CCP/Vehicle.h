#ifndef VEHICLE_H
#define VEHICLE_H

#include <iostream>
using namespace std;

class Route;

class Vehicle
{
protected:
    int vehicleId;
    string model;
    int capacity;
    int occupiedSeats;
    Route* routeAssigned;

public:
    Vehicle();
    Vehicle(int, string, int);
    Vehicle(const Vehicle&);
    Vehicle& operator=(const Vehicle&);

    int getVehicleId() const;
    string getModel() const;
    int getCapacity() const;
    int getOccupiedSeats() const;

    void setVehicleId(int);
    void setModel(string);
    void setCapacity(int);

    void assignRoute(Route*);
    bool hasSpace() const;
    void occupySeat();
    void freeSeat();

    virtual void displayVehicle() = 0;
    virtual ~Vehicle();
};

#endif
