#include "Vehicle.h"

Vehicle::Vehicle()
{
    vehicleId = 0;
    model = "";
    capacity = 0;
    occupiedSeats = 0;
    routeAssigned = nullptr;
}

Vehicle::Vehicle(int id, string m, int cap)
{
    vehicleId = id;
    model = m;
    capacity = cap;
    occupiedSeats = 0;
    routeAssigned = nullptr;
}

Vehicle::Vehicle(const Vehicle& obj)
{
    vehicleId = obj.vehicleId;
    model = obj.model;
    capacity = obj.capacity;
    occupiedSeats = obj.occupiedSeats;
    routeAssigned = obj.routeAssigned;
}

Vehicle& Vehicle::operator=(const Vehicle& obj)
{
    if (this != &obj)
    {
        vehicleId = obj.vehicleId;
        model = obj.model;
        capacity = obj.capacity;
        occupiedSeats = obj.occupiedSeats;
        routeAssigned = obj.routeAssigned;
    }
    return *this;
}

int Vehicle::getVehicleId() const { return vehicleId; }
string Vehicle::getModel() const { return model; }
int Vehicle::getCapacity() const { return capacity; }
int Vehicle::getOccupiedSeats() const { return occupiedSeats; }

void Vehicle::setVehicleId(int id) { vehicleId = id; }
void Vehicle::setModel(string m) { model = m; }
void Vehicle::setCapacity(int c) { capacity = c; }

void Vehicle::assignRoute(Route* r) { routeAssigned = r; }

bool Vehicle::hasSpace() const { return occupiedSeats < capacity; }

void Vehicle::occupySeat()
{
    if (occupiedSeats < capacity)
        occupiedSeats++;
}

void Vehicle::freeSeat()
{
    if (occupiedSeats > 0)
        occupiedSeats--;
}

Vehicle::~Vehicle() {}
