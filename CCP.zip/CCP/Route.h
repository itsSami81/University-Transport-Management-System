#ifndef ROUTE_H
#define ROUTE_H

#include <iostream>
using namespace std;

class Vehicle;

class Route
{
private:
    int routeId;
    string startPoint;
    string endPoint;
    string distance;
    Vehicle* assignedVehicle;

public:
    Route();
    Route(int, string, string, double);
    Route(const Route&);
    Route& operator=(const Route&);

    int getRouteId() const;
    string getStartPoint() const;
    string getEndPoint() const;
    string getDistance() const;

    void setRouteId(int);
    void setStartPoint(string);
    void setEndPoint(string);
    void setDistance(string);

    void assignVehicle(Vehicle*);

    void displayRoute() const;
    ~Route();
};

#endif
