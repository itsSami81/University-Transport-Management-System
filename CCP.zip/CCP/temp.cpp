#include <iostream>
using namespace std;
// template<typename T,typename U>
// auto add(T a, U b) 
//  { return a + b; }

// int main() {
    
//     cout << add(3, 2.5);
// }
class Base {
public:
    Base() { cout << "B "; }
    //  ~Base() { cout << "~B "; }
};
class Der : public Base {
public:
    Der() { cout << "D "; }
    // ~Der() { cout << "~D "; }
};
int main() {
    Base* p = new Der();
    delete p;
}