#ifndef STUDENT_H
#define STUDENT_H

#include "User.h"

class Student : public User
{
private:
    string department;
    bool transportApproved;

public:
    Student();
    Student(int, string, string, string, bool);
    Student(const Student&);
    Student& operator=(const Student&);

    void setDepartment(string);
    void setTransportStatus(bool);

    string getDepartment() const;
    bool getTransportStatus() const;

    void applyTransport();
    void cancelRegistration();

    void display() override;
    ~Student();
};

#endif
