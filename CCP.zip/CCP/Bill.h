#ifndef BILL_H
#define BILL_H

#include <iostream>
using namespace std;

class Bill
{
private:
    int billId;
    double baseFee;
    double lateFine;
    bool isPaid;

public:
    Bill();
    Bill(int, double);
    Bill(const Bill&);
    Bill& operator=(const Bill&);

    void setBillId(int);
    void setBaseFee(double);
    void setLateFine(double);
    void setPaymentStatus(bool);

    int getBillId() const;
    double getBaseFee() const;
    double getLateFine() const;
    bool getPaymentStatus() const;

    void applyLateFine(double);
    double calculateTotal() const;
    void markAsPaid();

    void displayBill() const;
    ~Bill();
};

#endif
