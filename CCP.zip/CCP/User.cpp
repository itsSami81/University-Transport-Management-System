#include "User.h"

User::User()
{
    id = 0;
    name = "";
    password = "";
}

User::User(int i, string n, string p)
{
    id = i;
    name = n;
    password = p;
}

User::User(const User& obj)
{
    id = obj.id;
    name = obj.name;
    password = obj.password;
}

User& User::operator=(const User& obj)
{
    if (this != &obj)
    {
        id = obj.id;
        name = obj.name;
        password = obj.password;
    }
    return *this;
}

void User::setId(int i) { id = i; }
void User::setName(string n) { name = n; }
void User::setPassword(string p) { password = p; }

int User::getId() const { return id; }
string User::getName() const { return name; }
string User::getPassword() const { return password; }

User::~User() {}
