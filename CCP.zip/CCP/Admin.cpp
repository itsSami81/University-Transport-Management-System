#include "Admin.h"

Admin::Admin() : User()
{
    designation = "";
}

Admin::Admin(int i, string n, string p, string d)
    : User(i, n, p)
{
    designation = d;
}

Admin::Admin(const Admin& obj) : User(obj)
{
    designation = obj.designation;
}

Admin& Admin::operator=(const Admin& obj)
{
    if (this != &obj)
    {
        User::operator=(obj);
        designation = obj.designation;
    }
    return *this;
}

void Admin::setDesignation(string d) { designation = d; }
string Admin::getDesignation() const { return designation; }

void Admin::display()
{
    cout << "\n========== ADMIN DETAILS ==========\n";
    cout << "ID          : " << id << endl;
    cout << "Name        : " << name << endl;
    cout << "Designation : " << designation << endl;
}

Admin::~Admin() {}
