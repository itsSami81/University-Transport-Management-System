#ifndef ADMIN_H
#define ADMIN_H

#include "User.h"

class Admin : public User
{
private:
    string designation;

public:
    Admin();
    Admin(int, string, string, string);
    Admin(const Admin&);
    Admin& operator=(const Admin&);

    void setDesignation(string);
    string getDesignation() const;

    void display() override;
    ~Admin();
};

#endif
