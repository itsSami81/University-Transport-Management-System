#ifndef TRANSPORTPASS_H
#define TRANSPORTPASS_H

#include <iostream>
#include "Bill.h"
using namespace std;

class Student;
class Vehicle;
class Route;

class TransportPass
{
private:
    int passId;
    int studentId;  
    int vehicleId;
    int routeId;
    Bill bill;
    bool approved;

public:
    TransportPass();
    TransportPass(int, int, int, int, double);
    TransportPass(const TransportPass&);
    TransportPass& operator=(const TransportPass&);

    int getPassId() const;
    int getStudentId() const;
    int getVehicleId() const;
    int getRouteId() const;
    bool isApproved() const;

    void setApproval(bool);
    void approve();
    void reject();

    void generateBill(double);
    void applyLateFine(double);
    void payBill();
    bool isBillPaid() const;

    void displayPass() const;
    ~TransportPass();
};

#endif
