#ifndef TRANSPORTMANAGER_H
#define TRANSPORTMANAGER_H

#include <iostream>
#include <fstream>

#include "Student.h"
#include "Admin.h"
#include "Bus.h"
#include "Van.h"
#include "Route.h"
#include "TransportPass.h"

using namespace std;

class TransportManager
{
private:
    Student**       students;
    Admin**         admins;
    Vehicle**       vehicles;
    Route**         routes;
    TransportPass** passes;

    int studentCount;
    int adminCount;
    int vehicleCount;
    int routeCount;
    int passCount;

public:
    TransportManager();
    ~TransportManager();

    // ---- Authentication ----
    Student* loginStudent(int id, string password);
    Admin*   loginAdmin(int id, string password);

    // ---- Student Management ----
    void addStudent(Student*);
    bool studentIdExists(int id);

    // ---- Admin Management ----
    void addAdmin(Admin*);

    // ---- Vehicle Management ----
    void addVehicle(Vehicle*);
    void removeVehicle(int id);
    bool vehicleIdExists(int id);

    // ---- Route Management ----
    void addRoute(Route*);
    bool routeIdExists(int id);

    // ---- Assignment ----
    void assignVehicleToRoute(int routeId, int vehicleId);

    // ---- Transport Application ----
    void applyTransport(int studentId, int routeId, int vehicleId, double fee);
    void cancelTransport(int studentId);

    // ---- Pass Management ----
    void approveRequest(int passId);
    void rejectRequest(int passId);
    void payBill(int passId);
    void applyLateFine(int passId, double fine);

    // ---- Display ----
    void displayAllStudents();
    void displayAllVehicles();
    void displayAllRoutes();
    void displayAllPasses();
    void displayStudentPass(int studentId);
    void generateReports();

    // ---- File I/O ----
    void saveData();
    void saveStudents();
    void loadStudents();
    void saveVehicles();
    void loadVehicles();
    void saveRoutes();
    void loadRoutes();
    void savePasses();
    void loadPasses();
};

#endif
