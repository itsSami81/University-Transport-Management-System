#ifndef BUS_H
#define BUS_H

#include "Vehicle.h"

class Bus : public Vehicle
{
private:
    string busType;

public:
    Bus();
    Bus(int, string, int, string);
    Bus(const Bus&);
    Bus& operator=(const Bus&);

    void setBusType(string);
    string getBusType() const;

    void displayVehicle() override;
    ~Bus();
};

#endif
