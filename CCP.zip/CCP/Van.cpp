#include "Van.h"

Van::Van() : Vehicle() { acAvailable = false; }

Van::Van(int id, string model, int cap, bool ac)
    : Vehicle(id, model, cap) { acAvailable = ac; }

Van::Van(const Van& obj) : Vehicle(obj) { acAvailable = obj.acAvailable; }

Van& Van::operator=(const Van& obj)
{
    if (this != &obj)
    {
        Vehicle::operator=(obj);
        acAvailable = obj.acAvailable;
    }
    return *this;
}

void Van::setAC(bool a) { acAvailable = a; }
bool Van::getAC() const { return acAvailable; }

void Van::displayVehicle()
{
    cout << "\n========== VAN DETAILS ==========\n";
    cout << "Vehicle ID     : " << vehicleId << endl;
    cout << "Model          : " << model << endl;
    cout << "Capacity       : " << capacity << endl;
    cout << "Occupied Seats : " << occupiedSeats << endl;
    cout << "Available Seats: " << (capacity - occupiedSeats) << endl;
    cout << "AC             : " << (acAvailable ? "Available" : "Not Available") << endl;
}

Van::~Van() {}
